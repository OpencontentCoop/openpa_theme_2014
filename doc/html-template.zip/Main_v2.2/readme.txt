Thanks for buying :)


The documentation is in the "documentation" folder. 
The HTML template is in the "html" folder. 
The PSD files are in the 'psd' folder. 


All psd files are well-organized and labeled which makes the customization process more smooth and painless.


If you have any question please contact us via http://velikorodnov.ticksy.com/

If you like our product, don�t forget to rate it. Thank you! :)